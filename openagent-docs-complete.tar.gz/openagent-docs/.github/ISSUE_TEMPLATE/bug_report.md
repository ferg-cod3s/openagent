---
name: Bug Report
about: Report a bug to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description

<!-- A clear and concise description of what the bug is -->

## Steps to Reproduce

1. 
2. 
3. 
4. 

## Expected Behavior

<!-- What you expected to happen -->

## Actual Behavior

<!-- What actually happened -->

## Environment

**OpenAgent Version:**
- Version: [e.g., v1.0.0]
- Commit SHA (if using main): [e.g., abc123]

**System Information:**
- OS: [e.g., Ubuntu 22.04, macOS 14.0]
- Architecture: [e.g., amd64, arm64]
- Go Version: [e.g., 1.21.3]
- Rust Version: [e.g., 1.75.0]

**Deployment:**
- [ ] Local development
- [ ] Docker
- [ ] Kubernetes
- [ ] Other: 

## Configuration

<!-- Relevant configuration (remove sensitive data) -->

```yaml
# Paste relevant config here
```

## Logs

<!-- Include relevant logs (remove sensitive data) -->

```
# Paste logs here
```

## Code Sample

<!-- If applicable, provide minimal code to reproduce the issue -->

```go
// Code to reproduce
```

## Screenshots

<!-- If applicable, add screenshots to help explain the problem -->

## Possible Solution

<!-- Optional: Suggest a fix/reason for the bug if you have one -->

## Impact

<!-- How critical is this bug? -->

- [ ] Blocks usage completely
- [ ] Causes data loss
- [ ] Performance degradation
- [ ] Workaround available
- [ ] Minor inconvenience

## Additional Context

<!-- Add any other context about the problem here -->

## Checklist

- [ ] I have searched existing issues to avoid duplicates
- [ ] I have provided all requested information
- [ ] I have removed all sensitive data from logs/config
- [ ] I have tested on the latest version
- [ ] I can reliably reproduce this issue
