# Contributing to OpenAgent

Thank you for your interest in contributing to OpenAgent! This document provides guidelines and instructions for contributing.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [How to Contribute](#how-to-contribute)
- [Coding Standards](#coding-standards)
- [Testing](#testing)
- [Submitting Changes](#submitting-changes)
- [Community](#community)

## Code of Conduct

We are committed to providing a welcoming and inclusive environment. Please read and follow our [Code of Conduct](CODE_OF_CONDUCT.md).

## Getting Started

### Prerequisites

- **Go:** 1.21 or higher
- **Rust:** 1.75 or higher (stable)
- **Docker:** For running integration tests
- **Git:** For version control
- **Make:** For build automation

### Development Tools

Install recommended development tools:

```bash
# Go tools
go install golang.org/x/tools/cmd/goimports@latest
go install github.com/golangci/golangci-lint/cmd/golangci-lint@latest
go install github.com/securego/gosec/v2/cmd/gosec@latest

# Rust tools
rustup component add rustfmt clippy
cargo install cargo-audit

# Pre-commit hooks
pip install pre-commit
pre-commit install
```

## Development Setup

### 1. Fork and Clone

```bash
# Fork the repository on GitHub, then clone your fork
git clone https://github.com/YOUR_USERNAME/openagent.git
cd openagent

# Add upstream remote
git remote add upstream https://github.com/openagent/openagent.git
```

### 2. Install Dependencies

```bash
# Go dependencies
go mod download

# Rust dependencies
cd core
cargo build
cd ..

# Set up local development database
make db-setup
```

### 3. Verify Setup

```bash
# Run tests to verify setup
make test

# Run linters
make lint

# Start development server
make dev
```

### 4. Environment Configuration

Create a `.env` file for local development:

```bash
# .env
DATABASE_URL=postgres://localhost/openagent_dev
API_PORT=8080
LOG_LEVEL=debug
ENABLE_DEBUG_MODE=true
```

## How to Contribute

### Types of Contributions

We welcome various types of contributions:

1. **Bug Reports** - Report bugs via GitHub Issues
2. **Feature Requests** - Suggest new features
3. **Code Contributions** - Fix bugs or implement features
4. **Documentation** - Improve or add documentation
5. **Tests** - Add or improve test coverage
6. **Examples** - Create example workflows or use cases

### Finding Work

- Check [Issues labeled "good first issue"](https://github.com/openagent/openagent/labels/good%20first%20issue)
- Look for [Issues labeled "help wanted"](https://github.com/openagent/openagent/labels/help%20wanted)
- Review the [Roadmap](docs/ROADMAP.md) for planned features

## Coding Standards

We follow strict coding standards to maintain code quality. Please review:

- [Code Quality Standards](docs/code-quality.md)
- [Git Workflow](docs/git-workflow.md)
- [Testing Standards](docs/testing-standards.md)
- [Security Guidelines](docs/security-guidelines.md)

### Key Standards

1. **SOLID Principles** - Write maintainable, extensible code
2. **YAGNI** - Don't over-engineer; implement what's needed
3. **DRY** - Avoid code duplication
4. **Test-Driven Development** - Write tests first
5. **Clear Naming** - Use descriptive, unambiguous names
6. **Small Functions** - Keep functions under 50 lines
7. **Documentation** - Document public APIs

### Code Style

**Go:**
```bash
# Format code
gofmt -w .
goimports -w .

# Run linters
golangci-lint run
```

**Rust:**
```bash
# Format code
cargo fmt

# Run linters
cargo clippy -- -D warnings
```

## Testing

### Running Tests

```bash
# Run all tests
make test

# Run only unit tests
make test-unit

# Run integration tests
make test-integration

# Run with coverage
make test-coverage

# View coverage report
make coverage-report
```

### Writing Tests

Follow our [Testing Standards](docs/testing-standards.md):

1. **Unit Tests** - Test individual functions/methods
2. **Integration Tests** - Test component interactions
3. **E2E Tests** - Test full workflows

**Example Unit Test (Go):**

```go
func TestAgent_Execute_Success(t *testing.T) {
    // Arrange
    agent := NewAgent(AgentConfig{ID: "test"})
    action := Action{Type: "tool_call"}
    
    // Act
    result, err := agent.Execute(action)
    
    // Assert
    require.NoError(t, err)
    assert.NotNil(t, result)
}
```

### Test Coverage Requirements

- Minimum 80% overall coverage
- 95%+ for critical paths (security, auth)
- 85%+ for new code in PRs

## Submitting Changes

### 1. Create a Branch

```bash
# Update your fork
git checkout develop
git pull upstream develop

# Create feature branch
git checkout -b feature/your-feature-name
```

### 2. Make Changes

- Write code following our standards
- Add tests for your changes
- Update documentation as needed
- Ensure all tests pass
- Run linters

### 3. Commit Changes

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```bash
# Stage changes
git add .

# Commit with conventional format
git commit -m "feat(agent): add evolution mutation operators"
```

**Commit Types:**
- `feat:` - New feature
- `fix:` - Bug fix
- `docs:` - Documentation
- `test:` - Tests
- `refactor:` - Code refactoring
- `perf:` - Performance improvement
- `chore:` - Maintenance

### 4. Push and Create PR

```bash
# Push to your fork
git push origin feature/your-feature-name

# Create Pull Request on GitHub
```

### 5. PR Requirements

Your PR must include:

- [ ] Clear description of changes
- [ ] Link to related issue (if applicable)
- [ ] Tests for new functionality
- [ ] Documentation updates
- [ ] All CI checks passing
- [ ] No merge conflicts
- [ ] Follows commit conventions

### 6. Code Review Process

1. Maintainers will review within 48 hours
2. Address feedback and requested changes
3. Re-request review after updates
4. Once approved, maintainer will merge

## Pull Request Template

When creating a PR, use this template:

```markdown
## Description
Brief description of changes

## Related Issue
Closes #123

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] Manual testing completed

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] Tests pass locally
- [ ] No new warnings
```

## Documentation

### Updating Documentation

- Update relevant `.md` files in `/docs`
- Update code comments and godoc/rustdoc
- Add examples for new features
- Update README.md if needed

### Documentation Structure

```
/docs
  global-rules.md           # Overview
  git-workflow.md           # Git conventions
  testing-standards.md      # Testing guidelines
  code-quality.md           # Code standards
  security-guidelines.md    # Security practices
  api-standards.md          # API conventions
  /ADR                      # Architecture decisions
```

## Development Workflow

### Daily Development

```bash
# 1. Update your branch
git checkout develop
git pull upstream develop

# 2. Create feature branch
git checkout -b feature/my-feature

# 3. Make changes and test
make test

# 4. Commit following conventions
git commit -m "feat: description"

# 5. Keep branch updated
git fetch upstream develop
git rebase upstream/develop

# 6. Push and create PR
git push origin feature/my-feature
```

### Debugging

```bash
# Run with debug logging
LOG_LEVEL=debug make dev

# Run specific test with verbose output
go test -v ./core -run TestAgent_Execute

# Profile performance
go test -bench=. -cpuprofile=cpu.prof
go tool pprof cpu.prof
```

## Community

### Communication Channels

- **GitHub Issues** - Bug reports and feature requests
- **GitHub Discussions** - General questions and discussions
- **Discord** - Real-time chat (coming soon)
- **Twitter** - [@openagent](https://twitter.com/openagent)

### Getting Help

- Review [Documentation](docs/)
- Check [FAQ](docs/FAQ.md)
- Search [existing issues](https://github.com/openagent/openagent/issues)
- Ask in [GitHub Discussions](https://github.com/openagent/openagent/discussions)

### Recognition

Contributors will be:
- Listed in [CONTRIBUTORS.md](CONTRIBUTORS.md)
- Credited in release notes
- Featured in project announcements

## License

By contributing, you agree that your contributions will be licensed under the [Apache 2.0 License](LICENSE).

## Questions?

If you have questions about contributing, please:
1. Check this guide and other documentation
2. Search existing GitHub issues
3. Open a new discussion on GitHub
4. Contact maintainers at dev@openagent.dev

Thank you for contributing to OpenAgent! 🚀
