# OpenAgent 🤖

**Autonomous agent framework with continuous evolution, client/server architecture, and MCP/A2A integration.**

[![CI/CD](https://github.com/openagent/openagent/workflows/CI/badge.svg)](https://github.com/openagent/openagent/actions)
[![Coverage](https://codecov.io/gh/openagent/openagent/branch/main/graph/badge.svg)](https://codecov.io/gh/openagent/openagent)
[![Go Report](https://goreportcard.com/badge/github.com/openagent/openagent)](https://goreportcard.com/report/github.com/openagent/openagent)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)

## Overview

OpenAgent is a production-ready autonomous agent platform with:

- **🔄 Continuous Evolution** - Agents improve through mutation, evaluation, and selection
- **🏗️ Client/Server Architecture** - Scalable runtime with thin client orchestration
- **🔌 MCP/A2A Integration** - Full support for Agent-to-Agent and Model Context Protocol
- **💾 Hybrid Memory** - Episodic, vector, and structured memory systems
- **📊 Built-in Evaluators** - Comprehensive fitness evaluation framework
- **🔐 Security First** - Sandboxed execution, capability-based access control
- **📝 File-Based Workflows** - YAML/JSON workflow definitions
- **🧪 Simulation Environments** - Deterministic testing and evaluation

## Quick Start

### Prerequisites

- Go 1.21+
- Rust 1.75+
- Docker (optional)
- PostgreSQL 15+ (optional)

### Installation

```bash
# Clone the repository
git clone https://github.com/openagent/openagent.git
cd openagent

# Install dependencies
make deps

# Build the project
make build

# Run tests
make test
```

### Running OpenAgent

```bash
# Start the server
./bin/openagent server

# In another terminal, use the CLI
./bin/openagent agent create --name "my-agent" --policy llm
./bin/openagent workflow run --file examples/simple-workflow.yaml
```

### Docker

```bash
# Build and run with Docker
docker-compose up

# Or using pre-built image
docker run -p 8080:8080 openagent/openagent:latest
```

## Features

### Core Capabilities

| Feature | Description | Status |
|---------|-------------|--------|
| Agent Runtime | Execute autonomous agents | ✅ |
| Continuous Evolution | Mutation and fitness-based improvement | ✅ |
| Workflow Engine | YAML/JSON workflow execution | ✅ |
| Memory System | Episodic, vector, structured memory | ✅ |
| Evaluators | Built-in fitness evaluation | ✅ |
| MCP/A2A Integration | Tool calling and agent communication | ✅ |
| REST API | Full HTTP API | ✅ |
| CLI | Command-line interface | ✅ |
| Web UI | Dashboard (coming soon) | 🚧 |

### Evolution Engine

OpenAgent agents continuously evolve through:

1. **Mutation Operators**
   - Prompt engineering
   - Tool weight adjustment
   - Memory configuration tuning
   - Hyperparameter optimization

2. **Fitness Evaluation**
   - Task success rate
   - Efficiency metrics
   - Safety compliance
   - Robustness testing

3. **Selection Strategy**
   - Multi-objective optimization
   - Canary testing
   - Rollback capability
   - Lineage tracking

### Memory System

```
┌─────────────────────────────────┐
│      Episodic Memory            │
│  (In-memory, per-session)       │
└─────────────────────────────────┘
┌─────────────────────────────────┐
│    Long-Term Vector Store       │
│  (FAISS/Qdrant/Milvus)          │
└─────────────────────────────────┘
┌─────────────────────────────────┐
│   Structured Knowledge Store    │
│  (PostgreSQL/SQLite)            │
└─────────────────────────────────┘
```

## Architecture

### High-Level Architecture

```
┌──────────────┐
│   Client     │ ◄─── REST/gRPC API
│ (CLI/UI/SDK) │ ◄─── MCP/A2A Messages
└──────────────┘
       │
       ▼
┌──────────────────────────────────┐
│   OpenAgent Runtime Server       │
│  ┌────────────────────────────┐  │
│  │  Agent Execution Engine    │  │
│  ├────────────────────────────┤  │
│  │  Evolution Engine          │  │
│  ├────────────────────────────┤  │
│  │  Workflow Engine           │  │
│  ├────────────────────────────┤  │
│  │  Memory Subsystem          │  │
│  ├────────────────────────────┤  │
│  │  Evaluator Library         │  │
│  ├────────────────────────────┤  │
│  │  Simulation Environments   │  │
│  └────────────────────────────┘  │
└──────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────┐
│  Tools & External Systems        │
│  (via MCP/A2A)                   │
└──────────────────────────────────┘
```

## Documentation

Comprehensive documentation is available in the [`/docs`](docs/) directory:

- **[Global Rules](docs/global-rules.md)** - Overview and principles
- **[Git Workflow](docs/git-workflow.md)** - Branch strategy and commit conventions
- **[Testing Standards](docs/testing-standards.md)** - TDD practices and coverage requirements
- **[Code Quality](docs/code-quality.md)** - SOLID, YAGNI, and coding standards
- **[Security Guidelines](docs/security-guidelines.md)** - Security best practices
- **[API Standards](docs/api-standards.md)** - REST API conventions
- **[Contributing Guide](CONTRIBUTING.md)** - How to contribute

### API Documentation

Interactive API documentation is available at: https://docs.openagent.dev/api

## Examples

### Creating an Agent

```go
package main

import (
    "github.com/openagent/core"
)

func main() {
    runtime := core.NewRuntime()
    
    agent, err := runtime.CreateAgent(core.AgentConfig{
        Name:   "research-agent",
        Policy: core.LLMPolicy{Model: "gpt-4"},
        Memory: core.HybridMemory{
            Episodic: true,
            Vector:   true,
        },
    })
    
    if err != nil {
        panic(err)
    }
    
    result, err := agent.Execute(core.Action{
        Type: "tool_call",
        Tool: "search",
        Args: map[string]interface{}{
            "query": "latest AI research",
        },
    })
}
```

### Workflow Example

```yaml
# simple-workflow.yaml
name: Research Workflow
agents:
  - id: researcher
    policy: llm
    tools: [search, summarize]

steps:
  - action: search
    agent: researcher
    args:
      query: "autonomous agents 2024"
    
  - action: summarize
    agent: researcher
    condition: "search.success"
    args:
      text: "{{search.result}}"
```

## Development

### Development Setup

```bash
# Set up development environment
make setup

# Run development server
make dev

# Run tests
make test

# Run linters
make lint

# Format code
make fmt
```

### Testing

```bash
# Run all tests
make test

# Unit tests only
make test-unit

# Integration tests
make test-integration

# E2E tests
make test-e2e

# Coverage report
make test-coverage
make coverage-report
```

### Pre-commit Checks

```bash
# Install Git hooks
make hooks

# Run pre-commit checks manually
make pre-commit
```

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Quick Contribution Guide

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Write/update tests
5. Run `make verify` to check code quality
6. Commit using conventional commits (`feat: add amazing feature`)
7. Push and create a Pull Request

## Security

Security is a top priority. Please review our [Security Policy](SECURITY.md) and report vulnerabilities to security@openagent.dev.

## Roadmap

### Q1 2025
- ✅ Core runtime and agent execution
- ✅ Workflow engine
- ✅ Memory subsystem
- 🚧 Web UI dashboard

### Q2 2025
- 🔮 Hierarchical agents
- 🔮 Advanced mutation operators
- 🔮 Multi-agent coordination
- 🔮 Cloud deployment templates

### Q3 2025
- 🔮 Agent marketplace
- 🔮 Plugin system
- 🔮 Performance optimizations
- 🔮 Advanced observability

## Performance

Benchmark results on MacBook Pro M1 Max:

| Operation | Throughput | Latency (p99) |
|-----------|-----------|---------------|
| Agent execution | 1000 ops/sec | 12ms |
| Memory retrieval | 5000 ops/sec | 3ms |
| Workflow execution | 200 workflows/sec | 45ms |
| Evolution cycle | 50 cycles/min | 850ms |

## License

OpenAgent is licensed under the [Apache 2.0 License](LICENSE).

## Community

- **GitHub Issues**: [Bug reports and feature requests](https://github.com/openagent/openagent/issues)
- **GitHub Discussions**: [Questions and discussions](https://github.com/openagent/openagent/discussions)
- **Twitter**: [@openagent](https://twitter.com/openagent)
- **Discord**: [Join our community](https://discord.gg/openagent) (coming soon)

## Citation

If you use OpenAgent in your research, please cite:

```bibtex
@software{openagent2024,
  title = {OpenAgent: Autonomous Agent Framework with Continuous Evolution},
  author = {OpenAgent Contributors},
  year = {2024},
  url = {https://github.com/openagent/openagent}
}
```

## Acknowledgments

Built with ❤️ by the OpenAgent community.

Special thanks to:
- Contributors who made this possible
- Open source projects we build upon
- The AI/ML research community

---

**Made with 🤖 by [OpenAgent](https://openagent.dev)**
