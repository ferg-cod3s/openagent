# API Standards

## API Design Principles

1. **RESTful** - Follow REST conventions for resource-based APIs
2. **Consistent** - Predictable patterns across all endpoints
3. **Versioned** - API versions to maintain backward compatibility
4. **Documented** - OpenAPI/Swagger specification for all endpoints
5. **Secure** - Authentication, authorization, rate limiting
6. **Developer-Friendly** - Clear errors, pagination, filtering

## REST API Conventions

### Resource Naming

Use **nouns, not verbs** in endpoint paths:

```
✅ Good:
GET    /agents
POST   /agents
GET    /agents/{id}
PATCH  /agents/{id}
DELETE /agents/{id}

❌ Bad:
GET    /getAgents
POST   /createAgent
GET    /agent/get/{id}
```

### HTTP Methods

| Method | Action          | Idempotent | Safe |
|--------|-----------------|------------|------|
| GET    | Retrieve        | Yes        | Yes  |
| POST   | Create          | No         | No   |
| PUT    | Replace         | Yes        | No   |
| PATCH  | Update (partial)| No         | No   |
| DELETE | Delete          | Yes        | No   |

### Resource Relationships

```
# Nested resources
GET /agents/{id}/workflows
GET /agents/{id}/workflows/{workflow_id}

# Multiple relationships
GET /agents/{id}/evaluators
POST /agents/{id}/evaluators
```

## API Versioning

### URI Versioning (Recommended)

```
https://api.openagent.dev/v1/agents
https://api.openagent.dev/v2/agents
```

**Advantages:**
- Clear and explicit
- Easy to route
- Cache-friendly

### Version Strategy

- **Major version (v1, v2):** Breaking changes
- **Minor version (v1.1, v1.2):** New features (backward compatible)
- **Patch version:** Bug fixes (not in URI)

**Version Lifecycle:**
- **Current:** Actively developed (v2)
- **Supported:** Maintained for 12 months (v1)
- **Deprecated:** 6-month sunset period before removal

### Deprecation Headers

```http
GET /v1/agents HTTP/1.1

HTTP/1.1 200 OK
Deprecation: true
Sunset: Sat, 31 Dec 2024 23:59:59 GMT
Link: <https://api.openagent.dev/v2/agents>; rel="successor-version"
```

## Request Format

### JSON Body

```json
POST /v1/agents
Content-Type: application/json

{
  "name": "research-agent",
  "policy": {
    "type": "llm",
    "model": "gpt-4"
  },
  "memory_config": {
    "type": "hybrid",
    "max_episodes": 100
  }
}
```

### Query Parameters

```
# Filtering
GET /v1/agents?status=active&policy=llm

# Sorting
GET /v1/agents?sort=created_at&order=desc

# Pagination
GET /v1/agents?page=2&limit=20

# Field selection
GET /v1/agents?fields=id,name,status
```

### Path Parameters

```
# Resource ID
GET /v1/agents/{agent_id}

# Sub-resources
GET /v1/agents/{agent_id}/workflows/{workflow_id}
```

## Response Format

### Success Responses

```json
GET /v1/agents/123

HTTP/1.1 200 OK
Content-Type: application/json

{
  "id": "123",
  "name": "research-agent",
  "status": "active",
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:30:00Z"
}
```

### Collection Responses

```json
GET /v1/agents

HTTP/1.1 200 OK
Content-Type: application/json

{
  "data": [
    {
      "id": "123",
      "name": "agent-1"
    },
    {
      "id": "456",
      "name": "agent-2"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 42,
    "total_pages": 3
  },
  "links": {
    "self": "/v1/agents?page=1",
    "next": "/v1/agents?page=2",
    "last": "/v1/agents?page=3"
  }
}
```

### Created Response

```json
POST /v1/agents

HTTP/1.1 201 Created
Location: /v1/agents/123
Content-Type: application/json

{
  "id": "123",
  "name": "new-agent",
  "status": "active"
}
```

### No Content Response

```
DELETE /v1/agents/123

HTTP/1.1 204 No Content
```

## Error Handling

### Error Response Format (RFC 7807 Problem Details)

```json
HTTP/1.1 400 Bad Request
Content-Type: application/problem+json

{
  "type": "https://docs.openagent.dev/errors/validation-error",
  "title": "Validation Error",
  "status": 400,
  "detail": "Agent name must be between 1 and 64 characters",
  "instance": "/v1/agents/123",
  "errors": [
    {
      "field": "name",
      "message": "Name too long",
      "code": "LENGTH_EXCEEDED"
    }
  ],
  "trace_id": "abc123def456"
}
```

### HTTP Status Codes

**Success (2xx):**
- `200 OK` - Successful GET, PATCH, PUT
- `201 Created` - Successful POST
- `202 Accepted` - Async operation started
- `204 No Content` - Successful DELETE

**Client Errors (4xx):**
- `400 Bad Request` - Invalid request data
- `401 Unauthorized` - Missing or invalid authentication
- `403 Forbidden` - Authenticated but not authorized
- `404 Not Found` - Resource doesn't exist
- `409 Conflict` - Resource conflict (e.g., duplicate)
- `422 Unprocessable Entity` - Valid JSON but semantic errors
- `429 Too Many Requests` - Rate limit exceeded

**Server Errors (5xx):**
- `500 Internal Server Error` - Generic server error
- `502 Bad Gateway` - Upstream service error
- `503 Service Unavailable` - Temporary unavailable
- `504 Gateway Timeout` - Upstream timeout

### Error Examples

```json
// 401 Unauthorized
{
  "type": "https://docs.openagent.dev/errors/unauthorized",
  "title": "Unauthorized",
  "status": 401,
  "detail": "Invalid or expired API key"
}

// 403 Forbidden
{
  "type": "https://docs.openagent.dev/errors/forbidden",
  "title": "Forbidden",
  "status": 403,
  "detail": "You don't have permission to delete this agent"
}

// 404 Not Found
{
  "type": "https://docs.openagent.dev/errors/not-found",
  "title": "Not Found",
  "status": 404,
  "detail": "Agent with ID '123' not found"
}

// 429 Rate Limit
{
  "type": "https://docs.openagent.dev/errors/rate-limit",
  "title": "Rate Limit Exceeded",
  "status": 429,
  "detail": "API rate limit exceeded. Try again in 60 seconds",
  "retry_after": 60
}
```

## Pagination

### Cursor-Based Pagination (Recommended)

```
GET /v1/agents?limit=20&cursor=eyJpZCI6MTIzfQ

Response:
{
  "data": [...],
  "pagination": {
    "next_cursor": "eyJpZCI6MTQzfQ",
    "prev_cursor": "eyJpZCI6MTAzfQ",
    "has_more": true
  }
}
```

**Advantages:**
- Consistent results during pagination
- Works well with real-time data
- No duplicate or missing items

### Offset-Based Pagination

```
GET /v1/agents?page=2&limit=20

Response:
{
  "data": [...],
  "pagination": {
    "page": 2,
    "limit": 20,
    "total": 100,
    "total_pages": 5
  }
}
```

## Filtering and Searching

### Query Parameters

```
# Simple filtering
GET /v1/agents?status=active

# Multiple values (OR)
GET /v1/agents?status=active,inactive

# Range queries
GET /v1/agents?created_after=2024-01-01&created_before=2024-12-31

# Full-text search
GET /v1/agents?q=research

# Nested filters
GET /v1/agents?policy.type=llm&policy.model=gpt-4
```

### Advanced Filtering

```
# Comparison operators
GET /v1/agents?fitness_score[gte]=0.8

# Array contains
GET /v1/agents?tools[contains]=calculator

# NOT operator
GET /v1/agents?status[ne]=archived
```

## Sorting

```
# Single field, ascending
GET /v1/agents?sort=name

# Single field, descending
GET /v1/agents?sort=-created_at

# Multiple fields
GET /v1/agents?sort=status,-created_at
```

## Field Selection

```
# Include specific fields only
GET /v1/agents?fields=id,name,status

# Exclude fields
GET /v1/agents?fields=-memory_config,-logs

# Nested field selection
GET /v1/agents?fields=id,policy(type,model)
```

## Authentication

### API Key Authentication

```http
GET /v1/agents HTTP/1.1
Authorization: Bearer sk_live_abc123xyz789
```

### JWT Authentication

```http
POST /v1/agents HTTP/1.1
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

### OAuth 2.0

```http
GET /v1/agents HTTP/1.1
Authorization: Bearer oauth2_access_token
```

## Rate Limiting

### Rate Limit Headers

```http
HTTP/1.1 200 OK
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 997
X-RateLimit-Reset: 1640995200
```

### Rate Limit Response

```json
HTTP/1.1 429 Too Many Requests
Retry-After: 60

{
  "type": "https://docs.openagent.dev/errors/rate-limit",
  "title": "Rate Limit Exceeded",
  "status": 429,
  "detail": "You have exceeded the API rate limit",
  "retry_after": 60
}
```

## CORS Configuration

```http
# Preflight request
OPTIONS /v1/agents HTTP/1.1
Origin: https://app.example.com
Access-Control-Request-Method: POST
Access-Control-Request-Headers: Content-Type, Authorization

# Preflight response
HTTP/1.1 204 No Content
Access-Control-Allow-Origin: https://app.example.com
Access-Control-Allow-Methods: GET, POST, PATCH, DELETE
Access-Control-Allow-Headers: Content-Type, Authorization
Access-Control-Max-Age: 86400
```

## Webhooks

### Webhook Payload

```json
POST https://your-server.com/webhook HTTP/1.1
Content-Type: application/json
X-OpenAgent-Signature: sha256=abc123...
X-OpenAgent-Event: agent.completed

{
  "event": "agent.completed",
  "timestamp": "2024-01-15T10:30:00Z",
  "data": {
    "agent_id": "123",
    "workflow_id": "456",
    "status": "success"
  }
}
```

### Webhook Signature Verification

```go
func VerifyWebhookSignature(payload []byte, signature string, secret string) bool {
    mac := hmac.New(sha256.New, []byte(secret))
    mac.Write(payload)
    expectedMAC := mac.Sum(nil)
    expectedSignature := "sha256=" + hex.EncodeToString(expectedMAC)
    return hmac.Equal([]byte(signature), []byte(expectedSignature))
}
```

## API Documentation (OpenAPI/Swagger)

### OpenAPI 3.0 Specification

```yaml
openapi: 3.0.0
info:
  title: OpenAgent API
  version: 1.0.0
  description: Autonomous agent runtime and management API

servers:
  - url: https://api.openagent.dev/v1

paths:
  /agents:
    get:
      summary: List agents
      parameters:
        - in: query
          name: status
          schema:
            type: string
            enum: [active, inactive, archived]
      responses:
        '200':
          description: Success
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/AgentList'
    post:
      summary: Create agent
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/AgentCreate'
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Agent'

components:
  schemas:
    Agent:
      type: object
      properties:
        id:
          type: string
        name:
          type: string
        status:
          type: string
          enum: [active, inactive, archived]
```

## Async Operations

### Long-Running Operations

```json
POST /v1/workflows/execute

HTTP/1.1 202 Accepted
Content-Type: application/json

{
  "operation_id": "op_123",
  "status": "pending",
  "links": {
    "status": "/v1/operations/op_123"
  }
}
```

### Check Operation Status

```json
GET /v1/operations/op_123

HTTP/1.1 200 OK

{
  "operation_id": "op_123",
  "status": "completed",
  "progress": 100,
  "result": {
    "workflow_id": "456",
    "status": "success"
  }
}
```

## Idempotency

### Idempotency Keys

```http
POST /v1/agents HTTP/1.1
Idempotency-Key: unique-key-123

{
  "name": "new-agent"
}
```

## Best Practices Summary

1. ✅ Use nouns for resources, not verbs
2. ✅ Version APIs in the URI
3. ✅ Return proper HTTP status codes
4. ✅ Use RFC 7807 for error responses
5. ✅ Implement pagination for collections
6. ✅ Support filtering, sorting, field selection
7. ✅ Rate limit all endpoints
8. ✅ Use API keys or OAuth for authentication
9. ✅ Provide comprehensive OpenAPI docs
10. ✅ Return meaningful error messages
11. ✅ Use HTTPS everywhere
12. ✅ Implement idempotency for mutations
