# Code Quality Standards

## Core Principles

### SOLID Principles

#### S - Single Responsibility Principle (SRP)
Each module, class, or function should have one and only one reason to change.

**Good:**
```go
// Separate concerns
type UserRepository struct {
    db *sql.DB
}

func (r *UserRepository) FindByID(id string) (*User, error) {
    // Only responsible for data access
}

type UserValidator struct{}

func (v *UserValidator) Validate(user *User) error {
    // Only responsible for validation
}
```

**Bad:**
```go
type UserService struct {
    db *sql.DB
}

func (s *UserService) CreateUser(user *User) error {
    // Multiple responsibilities: validation, persistence, notification
    if user.Email == "" {
        return errors.New("invalid email")
    }
    
    s.db.Exec("INSERT INTO users...")
    sendWelcomeEmail(user.Email)
}
```

#### O - Open/Closed Principle (OCP)
Software entities should be open for extension but closed for modification.

**Good:**
```go
// Interface for extension
type Evaluator interface {
    Evaluate(agent *Agent) (float64, error)
}

// Base implementation
type BaseEvaluator struct{}

// Extend without modifying base
type SuccessEvaluator struct {
    BaseEvaluator
}

func (e *SuccessEvaluator) Evaluate(agent *Agent) (float64, error) {
    // Custom evaluation logic
}
```

**Bad:**
```go
func Evaluate(agent *Agent, evalType string) (float64, error) {
    // Modifying function for each new evaluator type
    switch evalType {
    case "success":
        // ...
    case "efficiency":
        // ...
    // Adding new types requires modifying this function
    }
}
```

#### L - Liskov Substitution Principle (LSP)
Subtypes must be substitutable for their base types without altering correctness.

**Good:**
```go
type Storage interface {
    Save(key, value string) error
    Load(key string) (string, error)
}

type MemoryStorage struct{}
type DiskStorage struct{}

// Both can be used interchangeably
func ProcessData(storage Storage) {
    storage.Save("key", "value")
}
```

**Bad:**
```go
type BaseStorage interface {
    Save(key, value string) error
}

type ReadOnlyStorage struct{}

func (s *ReadOnlyStorage) Save(key, value string) error {
    // Violates LSP - throws error for expected operation
    return errors.New("read-only storage")
}
```

#### I - Interface Segregation Principle (ISP)
Clients should not be forced to depend on interfaces they don't use.

**Good:**
```go
// Small, focused interfaces
type Reader interface {
    Read() ([]byte, error)
}

type Writer interface {
    Write([]byte) error
}

type Closer interface {
    Close() error
}

// Compose as needed
type ReadWriteCloser interface {
    Reader
    Writer
    Closer
}
```

**Bad:**
```go
// Fat interface
type DataHandler interface {
    Read() ([]byte, error)
    Write([]byte) error
    Close() error
    Validate() error
    Transform() error
    Compress() error
    // Many methods not always needed
}
```

#### D - Dependency Inversion Principle (DIP)
Depend on abstractions, not concretions.

**Good:**
```go
// Depend on interface
type AgentService struct {
    repository AgentRepository // interface
}

func NewAgentService(repo AgentRepository) *AgentService {
    return &AgentService{repository: repo}
}
```

**Bad:**
```go
// Depend on concrete implementation
type AgentService struct {
    repository *PostgresRepository // concrete type
}

func NewAgentService() *AgentService {
    return &AgentService{
        repository: &PostgresRepository{},
    }
}
```

### YAGNI (You Aren't Gonna Need It)

Don't add functionality until it's actually needed. Avoid over-engineering.

**Good:**
```go
// Simple, meets current requirements
type Config struct {
    DatabaseURL string
    Port        int
}

func LoadConfig() (*Config, error) {
    return &Config{
        DatabaseURL: os.Getenv("DATABASE_URL"),
        Port:        8080,
    }, nil
}
```

**Bad:**
```go
// Over-engineered for future "possibilities"
type Config struct {
    Database DatabaseConfig
    Server   ServerConfig
    Cache    CacheConfig
    Queue    QueueConfig  // Not needed yet
    Metrics  MetricsConfig // Not needed yet
}

type ConfigProvider interface {
    Load() (*Config, error)
    Reload() error
    Watch() <-chan *Config
    Validate() error
}

// Complex config system we don't need yet
```

**YAGNI Guidelines:**
- ✅ Implement features when they're actually required
- ✅ Keep code simple and focused on current needs
- ✅ Refactor when new requirements emerge
- ❌ Don't build "flexible" systems for imagined future use cases
- ❌ Don't add configuration options "just in case"
- ❌ Don't abstract too early

**When to break YAGNI:**
- Security considerations (build in early)
- Fundamental architectural decisions
- API contracts that will be hard to change

### DRY (Don't Repeat Yourself)

Avoid duplication of logic. Each piece of knowledge should have a single, authoritative representation.

**Good:**
```go
func ValidateEmail(email string) error {
    // Single validation function
    if !emailRegex.MatchString(email) {
        return errors.New("invalid email")
    }
    return nil
}
```

**Bad:**
```go
func CreateUser(email string) error {
    if !emailRegex.MatchString(email) {
        return errors.New("invalid email")
    }
    // ...
}

func UpdateUser(email string) error {
    // Duplicated validation logic
    if !emailRegex.MatchString(email) {
        return errors.New("invalid email")
    }
    // ...
}
```

### KISS (Keep It Simple, Stupid)

Prefer simple solutions over complex ones.

**Good:**
```go
func Max(a, b int) int {
    if a > b {
        return a
    }
    return b
}
```

**Bad:**
```go
func Max(nums ...int) int {
    // Over-complicated for simple use case
    sort.Ints(nums)
    return nums[len(nums)-1]
}
```

## Naming Conventions

### General Rules

1. **Be descriptive and unambiguous**
2. **Use pronounceable names**
3. **Use searchable names**
4. **Avoid mental mapping**
5. **Don't be cute or use slang**

### Go Naming

```go
// Packages: lowercase, single word
package agent
package workflow

// Exported (public): PascalCase
type AgentConfig struct {}
func NewAgent() *Agent {}

// Unexported (private): camelCase
func validateConfig() error {}
var defaultTimeout = 30

// Constants: PascalCase or SCREAMING_SNAKE_CASE
const MaxRetries = 3
const DEFAULT_TIMEOUT = 30

// Interfaces: -er suffix when possible
type Reader interface {}
type Evaluator interface {}

// Acronyms: all caps or all lowercase
type HTTPServer struct {}  // not HttpServer
var apiKey string          // not APIKey

// Boolean names: is/has/can prefix
var isActive bool
var hasPermission bool
var canExecute bool
```

### Rust Naming

```rust
// Modules: snake_case
mod agent_runtime;
mod workflow_engine;

// Types: PascalCase
struct AgentConfig {}
enum PolicyType {}

// Functions: snake_case
fn create_agent() -> Agent {}
fn validate_config() -> Result<(), Error> {}

// Constants: SCREAMING_SNAKE_CASE
const MAX_RETRIES: u32 = 3;
const DEFAULT_TIMEOUT: Duration = Duration::from_secs(30);

// Traits: adjective or capability
trait Executable {}
trait Evaluator {}
```

### Variables

**Good:**
```go
var userCount int
var activeAgents []*Agent
var startTimestamp time.Time
```

**Bad:**
```go
var n int              // Too short, unclear
var data []interface{} // Too generic
var temp *Agent        // Meaningless name
```

### Functions

**Good:**
```go
func CalculateFitnessScore(agent *Agent) float64 {}
func SendNotification(user *User, message string) error {}
```

**Bad:**
```go
func DoStuff() {}        // Vague
func Process(x int) {}   // Unclear what it processes
func Go() {}             // Too generic
```

## Function Complexity

### Cyclomatic Complexity

Aim for cyclomatic complexity < 10 per function.

**Measuring complexity:**
```bash
# Go
gocyclo -over 10 .

# Rust
cargo install cargo-geiger
cargo geiger
```

### Function Length

- **Guideline:** Functions should be < 50 lines
- **Ideal:** 10-20 lines
- **Maximum:** 100 lines (with strong justification)

**Good:**
```go
func CreateAgent(config AgentConfig) (*Agent, error) {
    if err := validateConfig(config); err != nil {
        return nil, err
    }
    
    agent := &Agent{
        ID:     generateID(),
        Config: config,
    }
    
    if err := agent.initialize(); err != nil {
        return nil, err
    }
    
    return agent, nil
}
```

**Bad:**
```go
func CreateAgent(config AgentConfig) (*Agent, error) {
    // 200 lines of validation, initialization, error handling
    // Mix of concerns, hard to test, hard to understand
}
```

### Refactoring Long Functions

```go
// Before: Long function
func ProcessWorkflow(workflow *Workflow) error {
    // Validation logic (20 lines)
    // Parsing logic (30 lines)
    // Execution logic (40 lines)
    // Cleanup logic (15 lines)
}

// After: Extracted helpers
func ProcessWorkflow(workflow *Workflow) error {
    if err := validateWorkflow(workflow); err != nil {
        return err
    }
    
    steps, err := parseWorkflowSteps(workflow)
    if err != nil {
        return err
    }
    
    if err := executeSteps(steps); err != nil {
        return err
    }
    
    return cleanup(workflow)
}
```

## Code Organization

### File Structure

**Go:**
```
/package
  types.go        # Type definitions
  interface.go    # Interfaces
  service.go      # Business logic
  repository.go   # Data access
  handler.go      # HTTP handlers
  middleware.go   # Middleware
  errors.go       # Custom errors
  utils.go        # Utilities (avoid dumping ground)
```

**Rust:**
```
/module
  mod.rs          # Module interface
  types.rs        # Type definitions
  service.rs      # Business logic
  repository.rs   # Data access
  error.rs        # Error types
```

### Package/Module Size

- **Guideline:** < 1000 lines per file
- **Ideal:** 200-500 lines per file
- Split large files into logical submodules

### Import Organization

**Go:**
```go
import (
    // Standard library
    "context"
    "fmt"
    "time"
    
    // External dependencies
    "github.com/pkg/errors"
    "github.com/stretchr/testify/assert"
    
    // Internal packages
    "github.com/openagent/core"
    "github.com/openagent/types"
)
```

**Rust:**
```rust
// Standard library
use std::collections::HashMap;
use std::time::Duration;

// External crates
use serde::{Deserialize, Serialize};
use tokio::runtime::Runtime;

// Internal modules
use crate::agent::Agent;
use crate::types::Config;
```

## Error Handling

### Go

```go
// Return errors explicitly
func LoadConfig(path string) (*Config, error) {
    data, err := os.ReadFile(path)
    if err != nil {
        return nil, fmt.Errorf("failed to read config: %w", err)
    }
    
    var config Config
    if err := json.Unmarshal(data, &config); err != nil {
        return nil, fmt.Errorf("failed to parse config: %w", err)
    }
    
    return &config, nil
}

// Use error wrapping for context
if err != nil {
    return fmt.Errorf("loading agent config: %w", err)
}

// Define custom error types for specific cases
type ValidationError struct {
    Field   string
    Message string
}

func (e *ValidationError) Error() string {
    return fmt.Sprintf("%s: %s", e.Field, e.Message)
}
```

### Rust

```rust
// Use Result<T, E>
fn load_config(path: &str) -> Result<Config, Error> {
    let data = std::fs::read_to_string(path)
        .map_err(|e| Error::ConfigRead(e))?;
    
    let config: Config = serde_json::from_str(&data)
        .map_err(|e| Error::ConfigParse(e))?;
    
    Ok(config)
}

// Define custom error types
#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("Failed to read config: {0}")]
    ConfigRead(#[source] std::io::Error),
    
    #[error("Failed to parse config: {0}")]
    ConfigParse(#[source] serde_json::Error),
}
```

## Comments and Documentation

### When to Comment

✅ **Do comment:**
- Complex algorithms
- Non-obvious decisions
- Public APIs
- TODOs with context

❌ **Don't comment:**
- Obvious code
- Redundant information
- What the code does (code should be self-explanatory)

**Good:**
```go
// CalculateFitness computes a multi-objective fitness score
// for an agent based on success rate, efficiency, and safety.
// Weights are normalized to sum to 1.0.
func CalculateFitness(agent *Agent) float64 {
    // Use exponential moving average to handle recent performance
    // more heavily than historical data (decay factor = 0.9)
    score := calculateEMA(agent.metrics, 0.9)
    return score
}
```

**Bad:**
```go
// This function calculates fitness
func CalculateFitness(agent *Agent) float64 {
    // Get the score
    score := getScore(agent)
    // Return it
    return score
}
```

### Documentation Format

**Go (godoc):**
```go
// Package agent provides core agent runtime functionality.
package agent

// Agent represents an autonomous agent with a policy and memory.
//
// Example usage:
//     agent := NewAgent(config)
//     result, err := agent.Execute(action)
type Agent struct {
    ID     string
    Policy Policy
}

// Execute performs the given action and returns the result.
// It returns an error if the action is invalid or execution fails.
func (a *Agent) Execute(action Action) (*Result, error) {
    // ...
}
```

**Rust (rustdoc):**
```rust
/// Agent represents an autonomous agent with a policy and memory.
///
/// # Examples
///
/// ```
/// let agent = Agent::new(config);
/// let result = agent.execute(action)?;
/// ```
pub struct Agent {
    pub id: String,
    policy: Box<dyn Policy>,
}

/// Executes the given action and returns the result.
///
/// # Errors
///
/// Returns `Error::InvalidAction` if the action is invalid.
/// Returns `Error::ExecutionFailed` if execution fails.
pub fn execute(&self, action: Action) -> Result<ActionResult, Error> {
    // ...
}
```

## Linting and Formatting

### Go

```bash
# Install tools
go install golang.org/x/lint/golint@latest
go install honnef.co/go/tools/cmd/staticcheck@latest
go install github.com/golangci/golangci-lint/cmd/golangci-lint@latest

# Format code
gofmt -w .

# Run linters
golangci-lint run
```

**`.golangci.yml`:**
```yaml
linters:
  enable:
    - gofmt
    - golint
    - govet
    - errcheck
    - staticcheck
    - unused
    - gosimple
    - gocyclo

linters-settings:
  gocyclo:
    min-complexity: 10
```

### Rust

```bash
# Format code
cargo fmt

# Run linter
cargo clippy -- -D warnings
```

**`clippy.toml`:**
```toml
cognitive-complexity-threshold = 10
```

## Code Review Checklist

- [ ] Follows SOLID principles
- [ ] Applies YAGNI (not over-engineered)
- [ ] No duplication (DRY)
- [ ] Simple solution (KISS)
- [ ] Clear naming conventions
- [ ] Cyclomatic complexity < 10
- [ ] Functions < 50 lines
- [ ] Proper error handling
- [ ] Adequate documentation
- [ ] Tests included
- [ ] No commented-out code
- [ ] No hardcoded values (use constants)
- [ ] No secrets in code

## Anti-Patterns to Avoid

### God Object
```go
// Bad: Does everything
type AgentManager struct {
    // Handles execution, storage, evaluation, logging, etc.
}
```

### Shotgun Surgery
```go
// Bad: Changing one feature requires changes in many files
// Sign of poor separation of concerns
```

### Premature Optimization
```go
// Bad: Complex caching before profiling shows need
func GetAgent(id string) *Agent {
    // Overcomplicated cache with LRU, TTL, eviction
}
```

### Magic Numbers
```go
// Bad
if len(agents) > 100 { /* ... */ }

// Good
const MaxAgentCount = 100
if len(agents) > MaxAgentCount { /* ... */ }
```

### Long Parameter Lists
```go
// Bad
func CreateAgent(id, name, policy, memory, tools, timeout, retries, logLevel string) {}

// Good
func CreateAgent(config AgentConfig) {}
```

## Resources

- [Effective Go](https://golang.org/doc/effective_go)
- [Rust Book](https://doc.rust-lang.org/book/)
- [Clean Code by Robert Martin](https://www.amazon.com/Clean-Code-Handbook-Software-Craftsmanship/dp/0132350882)
- [SOLID Principles](https://en.wikipedia.org/wiki/SOLID)
