# Git Workflow

## Branch Strategy

### Branch Types

```
main              - Production-ready code, protected
develop           - Integration branch for features
feature/*         - New features (feature/agent-evolution)
bugfix/*          - Bug fixes (bugfix/memory-leak)
hotfix/*          - Critical production fixes (hotfix/security-patch)
release/*         - Release preparation (release/v1.0.0)
```

### Branch Naming Conventions

- Use lowercase with hyphens
- Be descriptive but concise
- Include issue/ticket number when applicable

**Examples:**
```
feature/continuous-evolution-engine
feature/123-mcp-broker-integration
bugfix/456-workflow-parsing-error
hotfix/789-api-authentication-bypass
release/v1.2.0
```

### Branch Protection Rules

**`main` branch:**
- Requires PR approval (minimum 1 reviewer)
- Requires passing CI/CD checks
- No direct commits allowed
- Requires linear history (rebase/squash merge)

**`develop` branch:**
- Requires passing CI/CD checks
- PR approval recommended but not required

## Commit Message Format

We follow [Conventional Commits](https://www.conventionalcommits.org/) specification.

### Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, no logic change)
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Adding or updating tests
- `build`: Build system or dependencies
- `ci`: CI/CD configuration changes
- `chore`: Other changes (tooling, etc.)

### Examples

```bash
feat(evolution): add mutation operators for policy evolution

Implemented prompt mutation, tool weight adjustment, and memory
configuration mutations. Each operator includes rollback capability.

Closes #123

---

fix(memory): resolve vector search timeout issue

Vector similarity search was timing out for large memory stores.
Added pagination and connection pooling.

Fixes #456

---

docs(api): update REST endpoint documentation

Added examples for /agents and /workflows endpoints.
Clarified authentication requirements.

---

test(workflow): add integration tests for YAML parsing

Added test coverage for complex workflow scenarios including
branching, conditionals, and parallel execution.

---

perf(runtime): optimize agent execution pipeline

Reduced agent initialization overhead by 40% through lazy loading
and connection pooling.

---

refactor(evaluator): extract scoring logic to separate module

Improved testability and separation of concerns for evaluator
scoring system.
```

### Commit Guidelines

1. **Subject line:**
   - Max 72 characters
   - Lowercase first word after scope
   - No period at the end
   - Imperative mood ("add" not "added" or "adds")

2. **Body (optional but recommended):**
   - Wrap at 72 characters
   - Explain *what* and *why*, not *how*
   - Separate from subject with blank line

3. **Footer (optional):**
   - Reference issues: `Closes #123`, `Fixes #456`, `Relates to #789`
   - Breaking changes: `BREAKING CHANGE: description`

## Pull Request Process

### Creating a PR

1. **Create feature branch from `develop`:**
   ```bash
   git checkout develop
   git pull origin develop
   git checkout -b feature/my-feature
   ```

2. **Make changes and commit:**
   ```bash
   git add .
   git commit -m "feat(scope): description"
   ```

3. **Keep branch up to date:**
   ```bash
   git fetch origin develop
   git rebase origin/develop
   ```

4. **Push and create PR:**
   ```bash
   git push origin feature/my-feature
   ```

### PR Requirements

- [ ] Descriptive title following commit convention
- [ ] Clear description of changes
- [ ] Links to related issues
- [ ] All CI checks passing
- [ ] No merge conflicts
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] Self-review completed

### PR Review Process

1. **Author responsibilities:**
   - Respond to feedback within 24 hours
   - Make requested changes
   - Re-request review after updates

2. **Reviewer responsibilities:**
   - Review within 48 hours
   - Provide constructive feedback
   - Approve or request changes clearly

3. **Merge criteria:**
   - At least 1 approval
   - All CI checks pass
   - No unresolved conversations
   - Branch up to date with target

## Release Workflow

### Semantic Versioning

We follow [Semantic Versioning 2.0.0](https://semver.org/):

```
MAJOR.MINOR.PATCH

MAJOR - Breaking changes
MINOR - New features (backward compatible)
PATCH - Bug fixes (backward compatible)
```

**Examples:**
- `v1.0.0` - Initial release
- `v1.1.0` - Added workflow engine
- `v1.1.1` - Fixed memory leak
- `v2.0.0` - Breaking API changes

### Release Process

1. **Create release branch:**
   ```bash
   git checkout develop
   git checkout -b release/v1.2.0
   ```

2. **Update version numbers:**
   - Update `VERSION` file
   - Update package manifests
   - Update CHANGELOG.md

3. **Final testing:**
   - Run full test suite
   - Perform manual smoke tests
   - Security scan

4. **Merge to main:**
   ```bash
   git checkout main
   git merge --no-ff release/v1.2.0
   git tag -a v1.2.0 -m "Release v1.2.0"
   git push origin main --tags
   ```

5. **Merge back to develop:**
   ```bash
   git checkout develop
   git merge --no-ff release/v1.2.0
   git push origin develop
   ```

6. **Delete release branch:**
   ```bash
   git branch -d release/v1.2.0
   git push origin --delete release/v1.2.0
   ```

### Hotfix Process

For critical production fixes:

1. **Create hotfix branch from `main`:**
   ```bash
   git checkout main
   git checkout -b hotfix/critical-security-fix
   ```

2. **Fix and test:**
   ```bash
   git commit -m "fix(security): patch authentication bypass"
   ```

3. **Merge to both `main` and `develop`:**
   ```bash
   # Update version (PATCH)
   git checkout main
   git merge --no-ff hotfix/critical-security-fix
   git tag -a v1.2.1 -m "Hotfix v1.2.1"
   
   git checkout develop
   git merge --no-ff hotfix/critical-security-fix
   
   git push origin main develop --tags
   ```

## Git Hooks

### Pre-commit Hook

Install pre-commit hooks to enforce standards:

```bash
#!/bin/bash
# .git/hooks/pre-commit

# Run linters
make lint || exit 1

# Run fast tests
make test-unit || exit 1

# Check commit message format (if amending)
if [ -f .git/COMMIT_EDITMSG ]; then
  grep -qE '^(feat|fix|docs|style|refactor|perf|test|build|ci|chore)(\(.+\))?: .{1,72}$' .git/COMMIT_EDITMSG || {
    echo "Error: Commit message doesn't follow conventional commits format"
    exit 1
  }
fi
```

### Commit-msg Hook

```bash
#!/bin/bash
# .git/hooks/commit-msg

commit_msg=$(cat "$1")

if ! echo "$commit_msg" | grep -qE '^(feat|fix|docs|style|refactor|perf|test|build|ci|chore)(\(.+\))?: .{1,72}'; then
  echo "Error: Commit message must follow format: type(scope): subject"
  echo "Example: feat(auth): add JWT token validation"
  exit 1
fi
```

## Tagging Conventions

- All releases must be tagged
- Tags follow `vMAJOR.MINOR.PATCH` format
- Annotated tags only (use `git tag -a`)
- Include changelog summary in tag message

**Examples:**
```bash
git tag -a v1.0.0 -m "Initial release with agent runtime and workflow engine"
git tag -a v1.1.0 -m "Add continuous evolution engine and evaluators"
git tag -a v1.1.1 -m "Fix memory leak in vector store"
```

## CI/CD Integration

### GitHub Actions Triggers

- **On push to `develop`:** Run tests and linting
- **On PR to `main` or `develop`:** Full CI pipeline + security scan
- **On tag push (`v*`):** Build release artifacts and publish
- **Nightly on `main`:** Full test suite + performance benchmarks

### Required Checks

All PRs must pass:
- [ ] Linting (golangci-lint, clippy)
- [ ] Unit tests (80%+ coverage)
- [ ] Integration tests
- [ ] Security scan (gosec, cargo-audit)
- [ ] Build verification

## Best Practices

1. **Commit frequently** - Small, logical commits are easier to review
2. **Pull before push** - Always sync with remote before pushing
3. **Write clear messages** - Future you will thank you
4. **Review your own PR first** - Catch obvious issues before reviewer
5. **Keep PRs small** - Aim for <400 lines changed when possible
6. **Don't commit secrets** - Use `.gitignore` and secret management
7. **Test before committing** - Ensure tests pass locally
8. **Use feature flags** - For large features, use flags to merge early

## Troubleshooting

### Undo last commit (not pushed)
```bash
git reset --soft HEAD~1
```

### Fix commit message (not pushed)
```bash
git commit --amend -m "new message"
```

### Resolve merge conflicts
```bash
git fetch origin develop
git rebase origin/develop
# Fix conflicts in files
git add .
git rebase --continue
```

### Reset branch to remote state
```bash
git fetch origin
git reset --hard origin/develop
```

### Interactive rebase to squash commits
```bash
git rebase -i HEAD~3  # Last 3 commits
# Mark commits as 'squash' or 's'
```
