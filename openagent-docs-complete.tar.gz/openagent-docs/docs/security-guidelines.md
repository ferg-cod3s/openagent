# Security Guidelines

## Security-First Mindset

Security is not a feature—it's a requirement. Every component must be designed with security in mind from the start.

### Core Security Principles

1. **Defense in Depth** - Multiple layers of security
2. **Least Privilege** - Minimal permissions necessary
3. **Fail Securely** - Errors should not expose sensitive data
4. **Trust Nothing** - Validate all inputs and interactions
5. **Audit Everything** - Comprehensive logging for security events

## Threat Model for Autonomous Agents

### Threat Categories

1. **Agent Autonomy Risks**
   - Unauthorized tool execution
   - Resource exhaustion attacks
   - Policy manipulation
   - Agent-to-agent attacks

2. **Data Security**
   - Memory poisoning
   - Sensitive data leakage
   - Unauthorized data access

3. **System Integrity**
   - Code injection
   - Configuration tampering
   - Privilege escalation

4. **Communication Security**
   - Man-in-the-middle attacks
   - Message tampering
   - Replay attacks

### Attack Vectors

```
User Input → Agent Policy → Tool Execution → External Systems
    ↓            ↓              ↓                ↓
  Inject      Manipulate    Escalate         Exfiltrate
```

## Authentication and Authorization

### API Authentication

```go
// JWT-based authentication
type AuthMiddleware struct {
    secretKey []byte
}

func (m *AuthMiddleware) Authenticate(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        token := extractToken(r)
        if token == "" {
            http.Error(w, "Unauthorized", http.StatusUnauthorized)
            return
        }
        
        claims, err := validateJWT(token, m.secretKey)
        if err != nil {
            http.Error(w, "Invalid token", http.StatusUnauthorized)
            return
        }
        
        ctx := context.WithValue(r.Context(), "user", claims)
        next.ServeHTTP(w, r.WithContext(ctx))
    })
}
```

### Capability-Based Authorization

```go
// Agent capabilities define what tools they can use
type Capability struct {
    Resource string   // e.g., "tool:filesystem"
    Actions  []string // e.g., ["read", "write"]
}

type AgentCapabilities struct {
    AgentID      string
    Capabilities []Capability
}

func (a *Agent) CanExecute(tool string, action string) bool {
    for _, cap := range a.capabilities.Capabilities {
        if cap.Resource == tool {
            for _, allowed := range cap.Actions {
                if allowed == action {
                    return true
                }
            }
        }
    }
    return false
}

// Usage
func (a *Agent) ExecuteTool(toolName, action string) error {
    if !a.CanExecute(toolName, action) {
        return &SecurityError{
            Type:    "unauthorized",
            Message: fmt.Sprintf("agent %s cannot execute %s.%s", 
                a.ID, toolName, action),
        }
    }
    // Execute tool
}
```

### Role-Based Access Control (RBAC)

```go
type Role string

const (
    RoleAdmin    Role = "admin"
    RoleDeveloper Role = "developer"
    RoleViewer    Role = "viewer"
)

type Permission string

const (
    PermAgentCreate Permission = "agent:create"
    PermAgentDelete Permission = "agent:delete"
    PermAgentView   Permission = "agent:view"
    PermToolExecute Permission = "tool:execute"
)

var rolePermissions = map[Role][]Permission{
    RoleAdmin: {
        PermAgentCreate,
        PermAgentDelete,
        PermAgentView,
        PermToolExecute,
    },
    RoleDeveloper: {
        PermAgentCreate,
        PermAgentView,
        PermToolExecute,
    },
    RoleViewer: {
        PermAgentView,
    },
}

func HasPermission(role Role, perm Permission) bool {
    perms, ok := rolePermissions[role]
    if !ok {
        return false
    }
    
    for _, p := range perms {
        if p == perm {
            return true
        }
    }
    return false
}
```

## Input Validation and Sanitization

### Validate All Inputs

```go
// Agent configuration validation
func ValidateAgentConfig(config *AgentConfig) error {
    if config.ID == "" {
        return &ValidationError{Field: "ID", Message: "required"}
    }
    
    // Prevent injection attacks
    if containsSQLInjection(config.ID) {
        return &ValidationError{Field: "ID", Message: "invalid characters"}
    }
    
    // Enforce length limits
    if len(config.ID) > 64 {
        return &ValidationError{Field: "ID", Message: "too long (max 64)"}
    }
    
    // Validate against whitelist
    if !isValidIDFormat(config.ID) {
        return &ValidationError{Field: "ID", Message: "invalid format"}
    }
    
    return nil
}

// Whitelist validation
var validIDRegex = regexp.MustCompile(`^[a-zA-Z0-9_-]+$`)

func isValidIDFormat(id string) bool {
    return validIDRegex.MatchString(id)
}
```

### Sanitize Tool Inputs

```go
// Sanitize before passing to external tools
func SanitizeToolInput(input string) string {
    // Remove null bytes
    input = strings.ReplaceAll(input, "\x00", "")
    
    // Escape shell metacharacters
    input = shellescape.Quote(input)
    
    // Limit length
    if len(input) > 4096 {
        input = input[:4096]
    }
    
    return input
}
```

### SQL Injection Prevention

```go
// Always use parameterized queries
func GetAgentByID(db *sql.DB, id string) (*Agent, error) {
    // Good: Parameterized query
    row := db.QueryRow("SELECT id, name FROM agents WHERE id = $1", id)
    
    var agent Agent
    err := row.Scan(&agent.ID, &agent.Name)
    return &agent, err
}

// Bad: String concatenation
func GetAgentByIDUnsafe(db *sql.DB, id string) (*Agent, error) {
    // Never do this!
    query := "SELECT id, name FROM agents WHERE id = '" + id + "'"
    row := db.QueryRow(query)
    // ...
}
```

## Secrets Management

### Never Hardcode Secrets

```go
// Bad: Hardcoded secrets
const APIKey = "sk_live_abc123"
const DatabasePassword = "password123"

// Good: Environment variables
func LoadConfig() (*Config, error) {
    return &Config{
        APIKey:      os.Getenv("API_KEY"),
        DatabaseURL: os.Getenv("DATABASE_URL"),
    }, nil
}
```

### Use Secret Management Systems

```go
// Integration with HashiCorp Vault
type VaultClient struct {
    client *vault.Client
}

func (v *VaultClient) GetSecret(path string) (string, error) {
    secret, err := v.client.Logical().Read(path)
    if err != nil {
        return "", fmt.Errorf("failed to read secret: %w", err)
    }
    
    value, ok := secret.Data["value"].(string)
    if !ok {
        return "", errors.New("invalid secret format")
    }
    
    return value, nil
}
```

### Encrypt Secrets at Rest

```go
import "github.com/gtank/cryptopasta"

func EncryptSecret(plaintext []byte, key *[32]byte) ([]byte, error) {
    return cryptopasta.Encrypt(plaintext, key)
}

func DecryptSecret(ciphertext []byte, key *[32]byte) ([]byte, error) {
    return cryptopasta.Decrypt(ciphertext, key)
}
```

## Data Protection

### Encryption at Rest

```sql
-- Use encrypted database columns
CREATE TABLE agents (
    id UUID PRIMARY KEY,
    name TEXT,
    policy_encrypted BYTEA,  -- Store encrypted
    created_at TIMESTAMP
);
```

```go
func SaveAgent(agent *Agent, key *[32]byte) error {
    // Encrypt sensitive data before storage
    encryptedPolicy, err := EncryptSecret(agent.Policy, key)
    if err != nil {
        return err
    }
    
    _, err = db.Exec(
        "INSERT INTO agents (id, name, policy_encrypted) VALUES ($1, $2, $3)",
        agent.ID, agent.Name, encryptedPolicy,
    )
    return err
}
```

### Encryption in Transit

```go
// Force TLS for all connections
tlsConfig := &tls.Config{
    MinVersion:               tls.VersionTLS13,
    PreferServerCipherSuites: true,
}

server := &http.Server{
    Addr:      ":8443",
    TLSConfig: tlsConfig,
}

server.ListenAndServeTLS("cert.pem", "key.pem")
```

### Sensitive Data Masking

```go
// Mask sensitive data in logs
func MaskSensitiveData(data string) string {
    if len(data) <= 4 {
        return "****"
    }
    return data[:2] + strings.Repeat("*", len(data)-4) + data[len(data)-2:]
}

// Usage in logging
log.Info("API request", 
    "api_key", MaskSensitiveData(apiKey),
    "user_id", userID,
)
```

## Sandboxed Execution

### Agent Execution Isolation

```go
// Each agent runs in isolated environment
type SandboxConfig struct {
    MaxMemoryMB    int
    MaxCPUPercent  int
    TimeoutSeconds int
    AllowedTools   []string
    NetworkAccess  bool
}

func (r *Runtime) ExecuteAgent(agent *Agent, config SandboxConfig) error {
    // Create isolated context with resource limits
    ctx, cancel := context.WithTimeout(context.Background(), 
        time.Duration(config.TimeoutSeconds)*time.Second)
    defer cancel()
    
    // Enforce memory limits
    memLimit := config.MaxMemoryMB * 1024 * 1024
    setMemoryLimit(memLimit)
    
    // Restrict tool access
    allowedTools := make(map[string]bool)
    for _, tool := range config.AllowedTools {
        allowedTools[tool] = true
    }
    
    // Execute with restrictions
    return agent.Execute(ctx, allowedTools)
}
```

### Container Isolation (Docker)

```dockerfile
# Minimal base image
FROM alpine:3.18

# Non-root user
RUN adduser -D -u 1000 agent
USER agent

# Read-only filesystem
VOLUME ["/tmp"]
WORKDIR /tmp

# Resource limits set via docker-compose
```

```yaml
# docker-compose.yml
services:
  agent-runtime:
    image: openagent:latest
    read_only: true
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL
    cap_add:
      - NET_BIND_SERVICE
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
```

## Security Logging and Auditing

### Security Event Logging

```go
type SecurityEvent struct {
    Timestamp   time.Time
    EventType   string
    AgentID     string
    UserID      string
    Action      string
    Resource    string
    Result      string // "allowed" or "denied"
    IPAddress   string
    Details     map[string]interface{}
}

func LogSecurityEvent(event SecurityEvent) {
    // Structured logging
    log.WithFields(logrus.Fields{
        "event_type": event.EventType,
        "agent_id":   event.AgentID,
        "user_id":    event.UserID,
        "action":     event.Action,
        "resource":   event.Resource,
        "result":     event.Result,
        "ip":         event.IPAddress,
    }).Info("Security event")
    
    // Store in security audit log
    storeAuditLog(event)
}

// Usage
func (a *Agent) ExecuteTool(tool string) error {
    if !a.CanExecute(tool, "execute") {
        LogSecurityEvent(SecurityEvent{
            EventType: "unauthorized_tool_execution",
            AgentID:   a.ID,
            Action:    "execute",
            Resource:  tool,
            Result:    "denied",
        })
        return ErrUnauthorized
    }
    
    // Execute tool
    LogSecurityEvent(SecurityEvent{
        EventType: "tool_execution",
        AgentID:   a.ID,
        Action:    "execute",
        Resource:  tool,
        Result:    "allowed",
    })
    
    return nil
}
```

### Tamper-Proof Audit Logs

```go
// Sign audit logs to prevent tampering
type SignedAuditLog struct {
    Event     SecurityEvent
    Signature []byte
}

func SignAuditLog(event SecurityEvent, privateKey *rsa.PrivateKey) (*SignedAuditLog, error) {
    // Serialize event
    data, err := json.Marshal(event)
    if err != nil {
        return nil, err
    }
    
    // Hash and sign
    hashed := sha256.Sum256(data)
    signature, err := rsa.SignPKCS1v15(rand.Reader, privateKey, 
        crypto.SHA256, hashed[:])
    if err != nil {
        return nil, err
    }
    
    return &SignedAuditLog{
        Event:     event,
        Signature: signature,
    }, nil
}

func VerifyAuditLog(log *SignedAuditLog, publicKey *rsa.PublicKey) error {
    data, _ := json.Marshal(log.Event)
    hashed := sha256.Sum256(data)
    
    return rsa.VerifyPKCS1v15(publicKey, crypto.SHA256, 
        hashed[:], log.Signature)
}
```

## Rate Limiting and DDoS Protection

### API Rate Limiting

```go
import "golang.org/x/time/rate"

type RateLimiter struct {
    limiters map[string]*rate.Limiter
    mu       sync.RWMutex
}

func NewRateLimiter() *RateLimiter {
    return &RateLimiter{
        limiters: make(map[string]*rate.Limiter),
    }
}

func (r *RateLimiter) GetLimiter(key string) *rate.Limiter {
    r.mu.RLock()
    limiter, exists := r.limiters[key]
    r.mu.RUnlock()
    
    if !exists {
        r.mu.Lock()
        // 10 requests per second, burst of 20
        limiter = rate.NewLimiter(10, 20)
        r.limiters[key] = limiter
        r.mu.Unlock()
    }
    
    return limiter
}

func RateLimitMiddleware(limiter *RateLimiter) func(http.Handler) http.Handler {
    return func(next http.Handler) http.Handler {
        return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
            key := r.RemoteAddr // or user ID
            
            if !limiter.GetLimiter(key).Allow() {
                http.Error(w, "Rate limit exceeded", http.StatusTooManyRequests)
                return
            }
            
            next.ServeHTTP(w, r)
        })
    }
}
```

### Agent Resource Limits

```go
type ResourceMonitor struct {
    maxConcurrentAgents int
    activeAgents        atomic.Int32
}

func (m *ResourceMonitor) AcquireSlot() error {
    current := m.activeAgents.Load()
    if current >= int32(m.maxConcurrentAgents) {
        return errors.New("max concurrent agents reached")
    }
    m.activeAgents.Add(1)
    return nil
}

func (m *ResourceMonitor) ReleaseSlot() {
    m.activeAgents.Add(-1)
}
```

## OWASP Top 10 Compliance

### 1. Injection Prevention
- ✅ Use parameterized queries
- ✅ Validate and sanitize all inputs
- ✅ Use ORMs with proper escaping

### 2. Broken Authentication
- ✅ Implement MFA where possible
- ✅ Use strong session management
- ✅ Enforce password complexity

### 3. Sensitive Data Exposure
- ✅ Encrypt data at rest and in transit
- ✅ Use TLS 1.3+
- ✅ Implement proper key management

### 4. XML External Entities (XXE)
- ✅ Disable XML external entity processing
- ✅ Use safe parsers

### 5. Broken Access Control
- ✅ Implement RBAC
- ✅ Enforce least privilege
- ✅ Deny by default

### 6. Security Misconfiguration
- ✅ Disable unnecessary features
- ✅ Keep dependencies updated
- ✅ Use security headers

### 7. Cross-Site Scripting (XSS)
- ✅ Escape output
- ✅ Use Content Security Policy
- ✅ Validate input

### 8. Insecure Deserialization
- ✅ Validate serialized data
- ✅ Use safe serialization formats
- ✅ Implement integrity checks

### 9. Using Components with Known Vulnerabilities
- ✅ Regular dependency scanning
- ✅ Automated updates
- ✅ Monitor security advisories

### 10. Insufficient Logging & Monitoring
- ✅ Log all security events
- ✅ Monitor for anomalies
- ✅ Set up alerts

## Security Testing

### Automated Security Scanning

```yaml
# .github/workflows/security.yml
name: Security Scan

on: [push, pull_request]

jobs:
  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run Gosec
        run: |
          go install github.com/securego/gosec/v2/cmd/gosec@latest
          gosec ./...
      
      - name: Run dependency check
        run: |
          go install golang.org/x/vuln/cmd/govulncheck@latest
          govulncheck ./...
      
      - name: Run Trivy scanner
        uses: aquasecurity/trivy-action@master
        with:
          scan-type: 'fs'
          scan-ref: '.'
```

### Penetration Testing Checklist

- [ ] Authentication bypass attempts
- [ ] Authorization escalation tests
- [ ] Injection attack vectors (SQL, command, etc.)
- [ ] API fuzzing
- [ ] Rate limit testing
- [ ] Session management tests
- [ ] Cryptographic implementation review

## Security Incident Response

### Incident Response Plan

1. **Detection** - Automated alerts, log monitoring
2. **Containment** - Isolate affected systems
3. **Investigation** - Root cause analysis
4. **Eradication** - Remove threat
5. **Recovery** - Restore services
6. **Lessons Learned** - Post-mortem

### Security Contact

Create `SECURITY.md`:

```markdown
# Security Policy

## Reporting a Vulnerability

Please report security vulnerabilities to: security@openagent.dev

Do NOT create public GitHub issues for security vulnerabilities.

Expected response time: 48 hours

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | :white_check_mark: |
| < 1.0   | :x:                |
```

## Security Best Practices Summary

1. ✅ Never trust user input
2. ✅ Use parameterized queries
3. ✅ Encrypt sensitive data
4. ✅ Implement proper authentication/authorization
5. ✅ Use TLS for all communications
6. ✅ Keep dependencies updated
7. ✅ Log security events
8. ✅ Implement rate limiting
9. ✅ Use sandboxed execution
10. ✅ Regular security audits
11. ✅ Follow OWASP guidelines
12. ✅ Have incident response plan
