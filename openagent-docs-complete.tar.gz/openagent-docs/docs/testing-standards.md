# Testing Standards

## Testing Philosophy

We follow **Test-Driven Development (TDD)** principles and maintain high test coverage to ensure code quality, reliability, and maintainability.

### Core Principles

1. **Write tests first** - Tests define the contract before implementation
2. **Test behavior, not implementation** - Focus on what, not how
3. **Fast feedback** - Tests should run quickly and fail clearly
4. **Deterministic** - Tests must be reliable and repeatable
5. **Isolated** - Tests should not depend on external state or order

## Test Pyramid

```
        /\
       /  \      E2E Tests (5%)
      /____\     - Full system integration
     /      \    - Slow, brittle
    /________\   Integration Tests (15%)
   /          \  - Module interactions
  /____________\ - Database, APIs
 /              \ Unit Tests (80%)
/________________\- Fast, isolated
                  - Business logic
```

### Coverage Requirements

- **Minimum overall coverage:** 80%
- **Critical paths:** 95%+ (auth, security, data integrity)
- **New code:** 85%+ coverage required for PR approval
- **Branches:** 75%+ branch coverage

## Test Organization

### Directory Structure

```
/project
  /cmd
  /core
    agent.go
    agent_test.go        # Unit tests
  /tests
    /integration         # Integration tests
    /e2e                 # End-to-end tests
    /fixtures            # Test data
    /mocks               # Generated mocks
    /testutil            # Test utilities
```

### File Naming

- **Go:** `*_test.go` (same package)
- **Rust:** `tests/` module or `#[cfg(test)]`
- **Integration:** `integration_*_test.go`
- **E2E:** `e2e_*_test.go`

## Unit Testing

### TDD Workflow (Red-Green-Refactor)

```
1. RED    - Write failing test
2. GREEN  - Write minimal code to pass
3. REFACTOR - Clean up code
4. REPEAT
```

### Example (Go)

```go
// agent_test.go
package core

import (
    "testing"
    "github.com/stretchr/testify/assert"
    "github.com/stretchr/testify/require"
)

func TestAgent_ExecuteAction_Success(t *testing.T) {
    // Arrange
    agent := NewAgent(AgentConfig{
        ID:     "test-agent",
        Policy: MockPolicy(),
    })
    action := Action{Type: "tool_call", Tool: "calculator"}
    
    // Act
    result, err := agent.ExecuteAction(action)
    
    // Assert
    require.NoError(t, err)
    assert.NotNil(t, result)
    assert.Equal(t, "success", result.Status)
}

func TestAgent_ExecuteAction_InvalidTool(t *testing.T) {
    agent := NewAgent(AgentConfig{ID: "test-agent"})
    action := Action{Type: "tool_call", Tool: "nonexistent"}
    
    result, err := agent.ExecuteAction(action)
    
    require.Error(t, err)
    assert.Nil(t, result)
    assert.Contains(t, err.Error(), "tool not found")
}
```

### Example (Rust)

```rust
// agent.rs
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_agent_execute_action_success() {
        // Arrange
        let agent = Agent::new(AgentConfig {
            id: "test-agent".to_string(),
            policy: mock_policy(),
        });
        let action = Action {
            action_type: "tool_call".to_string(),
            tool: "calculator".to_string(),
        };
        
        // Act
        let result = agent.execute_action(action);
        
        // Assert
        assert!(result.is_ok());
        assert_eq!(result.unwrap().status, "success");
    }

    #[test]
    #[should_panic(expected = "tool not found")]
    fn test_agent_execute_action_invalid_tool() {
        let agent = Agent::new(AgentConfig {
            id: "test-agent".to_string(),
            policy: mock_policy(),
        });
        let action = Action {
            action_type: "tool_call".to_string(),
            tool: "nonexistent".to_string(),
        };
        
        agent.execute_action(action).unwrap();
    }
}
```

### Unit Test Best Practices

1. **AAA Pattern** - Arrange, Act, Assert
2. **One assertion per test** (when possible)
3. **Clear test names** - `Test<Method>_<Scenario>_<ExpectedResult>`
4. **Test edge cases** - nil, empty, negative, boundary values
5. **Use table-driven tests** for multiple scenarios
6. **Mock external dependencies** - no database, network, filesystem

### Table-Driven Tests (Go)

```go
func TestAgent_ValidateConfig(t *testing.T) {
    tests := []struct {
        name    string
        config  AgentConfig
        wantErr bool
        errMsg  string
    }{
        {
            name:    "valid config",
            config:  AgentConfig{ID: "agent-1", Policy: validPolicy()},
            wantErr: false,
        },
        {
            name:    "missing ID",
            config:  AgentConfig{Policy: validPolicy()},
            wantErr: true,
            errMsg:  "agent ID is required",
        },
        {
            name:    "nil policy",
            config:  AgentConfig{ID: "agent-1", Policy: nil},
            wantErr: true,
            errMsg:  "policy is required",
        },
    }
    
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            err := ValidateConfig(tt.config)
            if tt.wantErr {
                require.Error(t, err)
                assert.Contains(t, err.Error(), tt.errMsg)
            } else {
                require.NoError(t, err)
            }
        })
    }
}
```

## Integration Testing

### Scope

- Tests interactions between modules
- Uses real dependencies (database, filesystem)
- Tests API contracts between components

### Example

```go
// integration_workflow_test.go
//go:build integration
// +build integration

package tests

import (
    "testing"
    "github.com/openagent/core"
)

func TestWorkflowEngine_ExecuteWorkflow_Integration(t *testing.T) {
    // Setup real database
    db := setupTestDB(t)
    defer db.Close()
    
    // Create real components
    runtime := core.NewRuntime(db)
    engine := core.NewWorkflowEngine(runtime)
    
    // Load workflow from fixture
    workflow, err := loadWorkflowFixture("simple_workflow.yaml")
    require.NoError(t, err)
    
    // Execute
    result, err := engine.Execute(workflow)
    
    // Assert
    require.NoError(t, err)
    assert.Equal(t, "completed", result.Status)
    
    // Verify database state
    agents := runtime.GetAgents()
    assert.Len(t, agents, 1)
}
```

### Running Integration Tests

```bash
# Skip by default
go test ./...

# Run explicitly
go test -tags=integration ./tests/integration/...

# Rust
cargo test --test integration_*
```

## End-to-End Testing

### Scope

- Tests complete user workflows
- Uses full system deployment
- Tests through API/CLI interfaces

### Example

```go
// e2e_agent_lifecycle_test.go
//go:build e2e
// +build e2e

package tests

func TestE2E_AgentLifecycle(t *testing.T) {
    // Start server
    server := startTestServer(t)
    defer server.Stop()
    
    client := NewAPIClient(server.URL)
    
    // Create agent
    agent, err := client.CreateAgent(AgentRequest{
        Name:   "test-agent",
        Policy: "default",
    })
    require.NoError(t, err)
    
    // Execute workflow
    result, err := client.ExecuteWorkflow(WorkflowRequest{
        AgentID: agent.ID,
        Steps:   []Step{{Action: "tool_call"}},
    })
    require.NoError(t, err)
    assert.Equal(t, "success", result.Status)
    
    // Verify metrics
    metrics, err := client.GetMetrics(agent.ID)
    require.NoError(t, err)
    assert.Greater(t, metrics.Actions, 0)
    
    // Delete agent
    err = client.DeleteAgent(agent.ID)
    require.NoError(t, err)
}
```

## Mocking and Stubbing

### Mocking Strategy

1. **Use interfaces** for dependencies
2. **Generate mocks** with tools (mockery, mockgen)
3. **Verify interactions** when behavior matters
4. **Stub responses** for simple cases

### Go Mocking (mockery)

```go
// Generate mocks
//go:generate mockery --name=PolicyInterface --output=./mocks

// Usage
func TestAgent_WithMockPolicy(t *testing.T) {
    mockPolicy := new(mocks.PolicyInterface)
    mockPolicy.On("Decide", mock.Anything).Return(Action{Type: "test"}, nil)
    
    agent := NewAgent(AgentConfig{Policy: mockPolicy})
    action, err := agent.NextAction()
    
    require.NoError(t, err)
    assert.Equal(t, "test", action.Type)
    mockPolicy.AssertExpectations(t)
}
```

### Rust Mocking (mockall)

```rust
use mockall::predicate::*;
use mockall::mock;

mock! {
    Policy {}
    impl PolicyTrait for Policy {
        fn decide(&self, state: &State) -> Action;
    }
}

#[test]
fn test_agent_with_mock_policy() {
    let mut mock_policy = MockPolicy::new();
    mock_policy
        .expect_decide()
        .returning(|_| Action { action_type: "test".to_string() });
    
    let agent = Agent::new_with_policy(mock_policy);
    let action = agent.next_action();
    
    assert_eq!(action.action_type, "test");
}
```

## Test Fixtures and Utilities

### Fixture Management

```go
// testutil/fixtures.go
package testutil

func LoadFixture(name string) ([]byte, error) {
    return os.ReadFile(filepath.Join("fixtures", name))
}

func LoadWorkflowFixture(name string) (*Workflow, error) {
    data, err := LoadFixture(name)
    if err != nil {
        return nil, err
    }
    
    var workflow Workflow
    err = yaml.Unmarshal(data, &workflow)
    return &workflow, err
}
```

### Test Database Setup

```go
// testutil/database.go
func SetupTestDB(t *testing.T) *sql.DB {
    t.Helper()
    
    db, err := sql.Open("sqlite3", ":memory:")
    require.NoError(t, err)
    
    // Run migrations
    err = runMigrations(db)
    require.NoError(t, err)
    
    t.Cleanup(func() {
        db.Close()
    })
    
    return db
}
```

## Performance Testing

### Benchmark Tests (Go)

```go
func BenchmarkAgent_ExecuteAction(b *testing.B) {
    agent := setupBenchAgent()
    action := Action{Type: "tool_call"}
    
    b.ResetTimer()
    for i := 0; i < b.N; i++ {
        agent.ExecuteAction(action)
    }
}

// Run: go test -bench=. -benchmem
```

### Load Testing

```bash
# Use k6 for API load testing
k6 run --vus 100 --duration 30s loadtest.js
```

## Testing Frameworks

### Go
- **testing** - Standard library
- **testify** - Assertions and mocking
- **gomock** - Mock generation
- **httptest** - HTTP testing
- **testcontainers** - Docker containers for tests

### Rust
- **cargo test** - Built-in test runner
- **mockall** - Mocking framework
- **proptest** - Property-based testing
- **criterion** - Benchmarking

## CI/CD Integration

### GitHub Actions Workflow

```yaml
name: Tests

on: [push, pull_request]

jobs:
  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-go@v4
        with:
          go-version: '1.21'
      - name: Run unit tests
        run: go test -v -race -coverprofile=coverage.out ./...
      - name: Upload coverage
        uses: codecov/codecov-action@v3
        with:
          file: ./coverage.out

  integration-tests:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_PASSWORD: test
    steps:
      - uses: actions/checkout@v3
      - name: Run integration tests
        run: go test -tags=integration -v ./tests/integration/...

  e2e-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Build
        run: make build
      - name: Run e2e tests
        run: go test -tags=e2e -v ./tests/e2e/...
```

## Coverage Reporting

```bash
# Generate coverage report
go test -coverprofile=coverage.out ./...

# View HTML report
go tool cover -html=coverage.out

# Check coverage threshold
go test -coverprofile=coverage.out ./... && \
  go tool cover -func=coverage.out | grep total | \
  awk '{if ($3+0 < 80) {print "Coverage below 80%"; exit 1}}'
```

## Test Documentation

Each test suite should include:

```go
/*
Package core_test contains unit tests for the agent runtime core.

Test Coverage:
- Agent lifecycle: creation, execution, termination
- Policy integration: decision making, tool selection
- Memory operations: read, write, query
- Error handling: invalid configs, missing tools

Run tests:
    go test ./core/...

Run with coverage:
    go test -cover ./core/...
*/
```

## Best Practices Summary

1. ✅ Write tests first (TDD)
2. ✅ Aim for 80%+ coverage
3. ✅ Use AAA pattern (Arrange, Act, Assert)
4. ✅ Keep tests fast and isolated
5. ✅ Mock external dependencies
6. ✅ Use table-driven tests for multiple scenarios
7. ✅ Test edge cases and error paths
8. ✅ Use descriptive test names
9. ✅ Clean up resources (defer, t.Cleanup)
10. ✅ Run tests in CI/CD pipeline

## Anti-Patterns to Avoid

- ❌ Testing implementation details
- ❌ Flaky tests (time-dependent, race conditions)
- ❌ Tests that depend on execution order
- ❌ Overly complex test setup
- ❌ Testing private methods directly
- ❌ Mocking everything (test real integrations too)
- ❌ Ignoring test failures
- ❌ Not updating tests with code changes
